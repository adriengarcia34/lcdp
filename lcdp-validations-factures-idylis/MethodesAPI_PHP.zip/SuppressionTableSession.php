<?php
//Initialisation client SOAP et authentification sans mise en place du header pour maintenir la session
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//Appel de la méthode pour supprimer un enregistrement d'une table
//Le premier paramètre est l'authentification
//Autres paramètres : nom de la table dans laquelle agir, valeur de clé primaire de l'occurence à supprimer
$oWS->SuppresionTableSession(array('_sessionID'=>$oSession->AuthentificationAvec3Parametres1Result,'_nomtable'=>'FB_FOURNISSEURS', '_clevalue'=>'51'));

?>