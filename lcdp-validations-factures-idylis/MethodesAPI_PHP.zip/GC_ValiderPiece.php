<?php
//Initialisation client SOAP et authentification placée dans le Header
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));
$oAuth['SessionID']= $oSession->AuthentificationAvec3Parametres1Result;
$oHeader= new SoapHeader('https://www.idylis.com/Idylisapi.asmx/','SessionIDHeader',$oAuth, false);
$oWS->__setSoapHeaders(array($oHeader));

//Appel de la méthode pour valider la saisie des pieces commerciales
//_piece= Type de piece à traiter (FA_FACTURES, FA_AVOIRS...) _codepiece= Code de la piece à traiter
$oWS->GC_ValiderPiece(array('_piece'=>'FA_FACTURES', '_codepiece'=>'1000'));

?>