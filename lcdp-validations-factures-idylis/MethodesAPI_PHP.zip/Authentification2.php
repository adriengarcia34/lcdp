<?php
//Similaire à la méthode d'authentification 1, 1 paramètre supplémentaire : Code Client Géré (valable pour abonnement Idylis Pack Expert uniquement)

//Initialisation client SOAP
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");

//Méthode d'authentification pour récupérer le jeton de session
$oSession= $oWS->authentification2(array('_codeAbonne'=>'MonCodeAbonné', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse', '_codeClientGere'=>'MonCodeClientGere'));

//On génère l'en-tête qui contient le jeton de session. Cet en-tête sera généré pour chaque appel d'une méthode de l'API afin de maintenir l'authentification de la session
$oAuth['SessionID']= $oSession->AuthentificationAvec4Parametres2Result;
$oHeader= new SoapHeader('https://www.idylis.com/Idylisapi.asmx/','SessionIDHeader',$oAuth, false);
$oWS->__setSoapHeaders(array($oHeader));

?>
