<?php
//Initialisation client SOAP et authentification sans mise en place du header pour maintenir la session
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//On appelle la méthode de lecture en précisant les paramètres
//de la table à lire, des critères de filtre, d'ordre, d'ajout des données des sous-tables, d'ajout des pièces jointes et s'il faut compresser la réponse
//La méthode 'LireTableSession' est identique à 'LireTable', si ce n'est qu'on ajoute en paramètre les données de session
$oRes= $oWS->LireTableSession(array('_sessionID'=>$oSession->AuthentificationAvec3Parametres1Result,'_nomtable'=>"FB_Fournisseurs", '_criteres'=>"", '_ordre'=>"", '_soustables'=>"0", '_pieceatache'=>"0", '_aveccompression'=>"0"));
//Le resultat est récupéré dans un objet SimpleXMLElement pour faciliter le traitement des données
$oResXML= new SimpleXMLElement($oRes->LireTableSessionResult);
//On parcourt chaque fiche de l'objet SimpleXMLElement correspondant à la réponse
//Pour afficher la valeur d'un champ pour l'item FICHE en cours, on utilise $nFiche->NOMCHAMP
foreach ($oResXML->FICHE as $nFiche)
{
	echo 'Code Fournisseur : '.$nFiche->CODEFOURNISSEUR.'<br>';
	echo 'Raison Sociale : '.$nFiche->NOM.'<br>';
	echo 'Adresse 1 : '.$nFiche->ADRESSE1.'<br>';
	echo 'Code postal : '.$nFiche->CP.'<br>';
	echo 'Ville : '.$nFiche->VILLE.'<br>';
}

?>