<?php
//Initialisation client SOAP et authentification placée dans le Header
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));
$oAuth['SessionID']= $oSession->AuthentificationAvec3Parametres1Result;
$oHeader= new SoapHeader('https://www.idylis.com/Idylisapi.asmx/','SessionIDHeader',$oAuth, false);
$oWS->__setSoapHeaders(array($oHeader));

//Appel de la méthode pour supprimer un enregistrement d'une table
//Paramètres : nom de la table dans laquelle agir, valeur de la clé primaire de l'occurence à supprimer
$oWS->SuppresionTable(array('_nomtable'=>'FB_FOURNISSEURS', '_clevalue'=>'51'));

?>