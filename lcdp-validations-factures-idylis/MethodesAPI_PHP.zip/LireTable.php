<?php
//Initialisation client SOAP et authentification placée dans le Header
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));
$oAuth['SessionID']= $oSession->AuthentificationAvec3Parametres1Result;
$oHeader= new SoapHeader('https://www.idylis.com/Idylisapi.asmx/','SessionIDHeader',$oAuth, false);
$oWS->__setSoapHeaders(array($oHeader));

//On appelle la méthode de lecture en précisant les paramètres
//de la table à lire, des critères de filtre, d'ordre, d'ajout des données des sous-tables, d'ajout des pièces jointes et s'il faut compresser la réponse
$oRes= $oWS->LireTable(array('_nomtable'=>"FB_Fournisseurs", '_criteres'=>"Pays='France'", '_ordre'=>"CODEFOURNISSEUR ASC", '_soustables'=>"0", '_pieceatache'=>"0", '_aveccompression'=>"0"));
//Le resultat est récupéré dans un objet SimpleXMLElement pour faciliter le traitement des données
$oResXML= new SimpleXMLElement($oRes->LireTableResult);
//On parcourt chaque fiche de l'objet SimpleXMLElement correspondant à la réponse
//Pour afficher la valeur d'un champ pour l'item FICHE en cours, on utilise $nFiche->NOMCHAMP
foreach ($oResXML->FICHE as $nFiche)
{
	echo 'Code Fournisseur : '.$nFiche->CODEFOURNISSEUR.'<br>';
	echo 'Raison Sociale : '.$nFiche->NOM.'<br>';
	echo 'Adresse 1 : '.$nFiche->ADRESSE1.'<br>';
	echo 'Code postal : '.$nFiche->CP.'<br>';
	echo 'Ville : '.$nFiche->VILLE.'<br>';
}

?>