<?php
//Initialisation client SOAP et authentification sans mise en place du header pour maintenir la session
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//Apel de la méthode pour valider la saisie des écritures existant dans les grilles de saisie
//On place l'authentification comme premier paramètre
//Paramètre action: '1' pour brouillard, '2' pour ecritures
//Paramètre rapide: '0' pour grille de saisie en vrac, '1' pour grille de saisie rapide en vrac
$oWS->CP_ValiderGrilleSaisieSession(array('_sessionID'=>$oSession->AuthentificationAvec3Parametres1Result,'_action'=>'2', '_rapide'=>'1'));

?>