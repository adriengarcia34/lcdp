<?php
//Similaire à la méthode d'authentification 1, 2 paramètres supplémentaires: Code Client Géré et Nom de l'exercice (valable pour abonnement Idylis Pack Expert uniquement)

//Initialisation client SOAP
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");

//Méthode d'authentification pour récupérer le jeton de session
$oSession= $oWS->authentification3(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse', '_codeClientGere'=>'MonCodeClientGere', '_nomExercice'=>'MonNomExercice'));

//On génère l'en-tête qui contient le jeton de session. Cet en-tête sera généré pour chaque appel d'une méthode de l'API afin de maintenir l'authentification de la session
$oAuth['SessionID']= $oSession->AuthentificationAvec5Parametres3Result;
$oHeader= new SoapHeader('https://www.idylis.com/Idylisapi.asmx/','SessionIDHeader',$oAuth, false);
$oWS->__setSoapHeaders(array($oHeader));

?>
