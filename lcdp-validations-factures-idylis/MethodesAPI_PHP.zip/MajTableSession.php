<?php
//Initialisation client SOAP et authentification sans mise en place du header pour maintenir la session
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//On crée la châine XML contenant les données à modifier dans la table, la clé primaire de la table doit y figurer
$cFiche=
"<FB_FOURNISSEURS>
	<FICHE>
		<CODEFOURNISSEUR>238</CODEFOURNISSEUR>
		<ADRESSE1>8 rue du cherchemin</ADRESSE1>
	</FICHE>
</FB_FOURNISSEURS>";

//Appel de la méthode de mise à jour de table avec _cFiche en paramètre pour les données à mettre à jour
//Le premier paramètre à passer est l'authentification
$oWS->MajTableSession(array('_sessionID'=>$oSession->AuthentificationAvec3Parametres1Result,'_cFiche'=>$cFiche));

?>
