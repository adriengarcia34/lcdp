<?php
//Initialisation client SOAP et authentification sans mise en place du header pour maintenir la session
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//Appel de la méthode pour valider la saisie des pieces commerciales
//On place comme premier paramètre l'authentification
//piece= Type de piece à traiter (FA_FACTURES, FA_AVOIRS...) _codepiece= Code de la piece à traiter
$oWS->GC_ValiderPieceSession(array('_sessionID'=>$oSession->AuthentificationAvec3Parametres1Result,'_piece'=>'FA_FACTURES', '_codepiece'=>'1000'));

?>