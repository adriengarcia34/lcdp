<?php
//Initialisation client SOAP et authentification sans mise en place du header pour maintenir la session
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//Appel de la méthode pour purger les écritures de la comptabilité existant dans les grilles de saisie
//On ajoute en paramètre les données de session
$oWS->CP_PurgerGrilleSaisieSession(array('_sessionID'=>$oSession->AuthentificationAvec3Parametres1Result));

?>