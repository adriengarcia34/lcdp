<?php
//Initialisation client SOAP et authentification placée dans le Header
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));
$oAuth['SessionID']= $oSession->AuthentificationAvec3Parametres1Result;
$oHeader= new SoapHeader('https://www.idylis.com/Idylisapi.asmx/','SessionIDHeader',$oAuth, false);
$oWS->__setSoapHeaders(array($oHeader));

//On crée la châine XML contenant les données à insérer dans la table
$cFiche=
"<FB_FOURNISSEURS>
	<FICHE>
		<CODEFOURNISSEUR>51</CODEFOURNISSEUR>
		<NOM>GAMMA</NOM>
		<ADRESSE1>Avenue des peupliers</ADRESSE1>
		<CP>75001</CP>
		<VILLE>PARIS</VILLE>
	</FICHE>
</FB_FOURNISSEURS>";

//Appel de la méthode d'insertion avec le paramètre _cFiche correspondant à l'enregistrement à insérer
$oWS->InsererTable(array('_cFiche'=>$cFiche->FICHE));

?>