<?php
//Initialisation client SOAP
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");

//Méthode d'authentification pour récupérer le jeton de session
$oSession= $oWS->authentification_revendeur(array('_codeRevendeur'=>'MonCodeRevendeur', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//On génère l'en-tête qui contient le jeton de session. Cet en-tête sera généré pour chaque appel d'une méthode de l'API afin de maintenir l'authentification de la session
$oAuth['SessionID']= $oSession->Authentification_Revendeur;
$oHeader= new SoapHeader('https://www.idylis.com/Idylisapi.asmx/','SessionIDHeader',$oAuth, false);
$oWS->__setSoapHeaders(array($oHeader));

?>
