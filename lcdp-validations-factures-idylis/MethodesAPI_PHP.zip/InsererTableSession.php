<?php
//Initialisation client SOAP et authentification sans mise en place du header pour maintenir la session
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//On crée la châine XML contenant les données à insérer dans la table
$cFiche=
"<FB_FOURNISSEURS>
	<FICHE>
		<CODEFOURNISSEUR>51</CODEFOURNISSEUR>
		<NOM>GAMMA</NOM>
		<ADRESSE1>Avenue des peupliers</ADRESSE1>
		<CP>75001</CP>
		<VILLE>PARIS</VILLE>
	</FICHE>
</FB_FOURNISSEURS>";

//Appel de la méthode d'insertion avec le paramètre _cFiche correspondant à l'enregistrement à insérer
//Le premier paramètre à passer est l'authentification
$oWS->InsererTableSession(array('_sessionID'=>$oSession->AuthentificationAvec3Parametres1Result,'_cFiche'=>$cFiche));

?>