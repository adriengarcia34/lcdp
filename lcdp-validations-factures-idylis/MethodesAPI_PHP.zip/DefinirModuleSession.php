<?php
//Initialisation client SOAP et authentification sans mise en place du header pour maintenir la session
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//Appel de la méthode pour sélectionner la base de données sur laquelle se connecter en fonction du module à utiliser
//On place comme premier paramètre l'authentification
$oWS->DefinirModuleSession(array('_sessionID'=>$oSession->AuthentificationAvec3Parametres1Result,'_codemodule'=>'FA'));

?>