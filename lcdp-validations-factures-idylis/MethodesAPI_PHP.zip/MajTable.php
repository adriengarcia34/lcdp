<?php
//Initialisation client SOAP et authentification placée dans le Header
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));
$oAuth['SessionID']= $oSession->AuthentificationAvec3Parametres1Result;
$oHeader= new SoapHeader('https://www.idylis.com/Idylisapi.asmx/','SessionIDHeader',$oAuth, false);
$oWS->__setSoapHeaders(array($oHeader));

//On crée la châine XML contenant les données à modifier dans la table, la clé primaire de la table doit y figurer
$cFiche=
"<FB_FOURNISSEURS>
	<FICHE>
		<CODEFOURNISSEUR>238</CODEFOURNISSEUR>
		<ADRESSE1>8 rue du cherchemin</ADRESSE1>
	</FICHE>
</FB_FOURNISSEURS>";

//Appel de la méthode de mise à jour de table avec _cFiche en paramètre pour les données à mettre à jour
$oWS->MajTable(array('_cFiche'=>$cFiche));

?>
