<?php
//Initialisation client SOAP et authentification placée dans le Header
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));
$oAuth['SessionID']= $oSession->AuthentificationAvec3Parametres1Result;
$oHeader= new SoapHeader('https://www.idylis.com/Idylisapi.asmx/','SessionIDHeader',$oAuth, false);
$oWS->__setSoapHeaders(array($oHeader));

//On crée la châine XML contenant les données à modifier dans la table
$cFiche=
"<FB_FOURNISSEURS>
	<FICHE>
		<CODEFOURNISSEUR>238</CODEFOURNISSEUR>
		<ADRESSE1>8 rue du cherchemin</ADRESSE1>
		<FB_CONTACTSFOURNISSEURS>
			<SOUSFICHE>
				<CODEFOURNISSEUR>238</CODEFOURNISSEUR>
				<TEL>0836656565</TEL>
				<NOM>Siozac</NOM>
				<PRENOM>Jean-Michel</PRENOM>
			</SOUSFICHE>
			<SOUSFICHE>
				<CODEFOURNISSEUR>238</CODEFOURNISSEUR>
				<TEL>0836656566</TEL>
				<NOM>Loincan</NOM>
				<PRENOM>Adam</PRENOM>
			</SOUSFICHE>
		</FB_CONTACTSFOURNISSEURS>
	</FICHE>
</FB_FOURNISSEURS>";

//Appel de la méthode de mise à jour la table et sous-table
// Paramètres :
// _cFiche => châine XML avec les données à mettre à jour
// _cNomSousTable => sous-table à mettre à jour
// _cCleSousTable => nom du champ faisant office de clé primaire
// _cCleSousTable2 => optionnel, dans le cas où il n'existe pas de clé primaire pour identifier l'enregistrement, on utilise deux champs
// Exemple: nom et prénom pour contact fournisseur
$oWS->MajSousTable(array('_cFiche'=>$cFiche, '_cNomSousTable'=>'FB_ContactsFournisseurs' , '_cCleSousTable'=>'NOM', '_cCleSousTable2'=>'PRENOM'));






?>
