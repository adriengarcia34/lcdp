<?php
//Initialisation client SOAP et authentification sans mise en place du header pour maintenir la session
$oWS= new SoapClient("http://exe.idylis.com/idylisapi.asmx?wsdl");
$oSession= $oWS->authentification1(array('_codeAbonne'=>'MonCodeAbonne', '_identifiant'=>'MonIdentifiant', '_motdePasse'=>'MonMotDePasse'));

//On appelle la méthode pour récupérer la référence de l'utilisateur qui a ouvert la session
//En précisant l'authentification comme paramètre
$oRes= $oWS->RefUtilisateurSession(array('_sessionID'=>$oSession->AuthentificationAvec3Parametres1Result));
//Le resultat est récupéré dans un objet SimpleXMLElement pour faciliter le traitement des données
$oResXML= new SimpleXMLElement($oRes->RefUtilisateurSessionResult);
//On affiche le contenu de la réponse
echo ($oResXML->message[0]);

?>
